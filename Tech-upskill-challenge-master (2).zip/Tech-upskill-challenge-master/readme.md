# this was the challenge from tech upskill

## the two questions are both included in the same file

## they are both separated by the comments and other brief information needed
